package vip.itellyou.pojo;

import vip.itellyou.util.base.BaseQueryModel;

public class RecordQueryModel extends Record implements BaseQueryModel {

}
