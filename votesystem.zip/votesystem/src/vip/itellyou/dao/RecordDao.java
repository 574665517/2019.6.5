package vip.itellyou.dao;

import vip.itellyou.util.base.BaseDao;


public interface RecordDao extends BaseDao {
}
