package vip.itelyou.test;

import org.junit.jupiter.api.Test;

import vip.itellyou.ui.servlet.DoLoginServlet;

/**
 * @author ywx
 * @ date 2019��4��21��
 */
class LoginTest extends DoLoginServlet {

	private static final long serialVersionUID = 7148315225359851359L;

	/**
	 * {@link vip.itellyou.ui.servlet.DoLoginServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)} �Ĳ��Է�����
	 */
	@Test
	void testDoGetHttpServletRequestHttpServletResponse() {
		
	}

	/**
	 * {@link vip.itellyou.ui.servlet.DoLoginServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)} �Ĳ��Է�����
	 */
	@Test
	void testDoPostHttpServletRequestHttpServletResponse() {
		
	}

}
